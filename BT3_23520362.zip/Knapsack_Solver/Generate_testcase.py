import os
import random

def generate_knapsack_test(file_path, num_items, max_value, max_weight, capacity):
    with open(file_path, 'w') as f:
        f.write(f"{num_items}\n")
        f.write(f"{capacity}\n")
        for _ in range(num_items):
            value = random.randint(1, max_value)
            weight = random.randint(1, max_weight)
            f.write(f"{value} {weight}\n")

def create_test_group(folder_path, num_tests=5):
    os.makedirs(folder_path, exist_ok=True)
    for i in range(1, num_tests + 1):
        file_path = os.path.join(folder_path, f"test{i:02d}.kp")
        # Tùy chỉnh độ khó tại đây:
        num_items = random.randint(10, 100)          # số lượng vật phẩm
        max_value = random.randint(50, 1000)         # giá trị tối đa của vật phẩm
        max_weight = random.randint(10, 100)         # trọng lượng tối đa của vật phẩm
        capacity = random.randint(100, 1000)         # sức chứa của balo
        generate_knapsack_test(file_path, num_items, max_value, max_weight, capacity)

for i in range (0, 13):
    create_test_group(f"./testcase/{i:02d}")