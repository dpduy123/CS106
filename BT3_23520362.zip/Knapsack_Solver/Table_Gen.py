import pandas as pd

df = pd.read_csv("knapsack_results.csv")

columns = ["Group", "Test", "Items", "Value", "Weight", "IsOptimal", "TimeUsed(s)"]

latex_code = df[columns].to_latex(index=False)

with open("result_table.tex", "w") as f:
    f.write("% Generated Knapsack Group Results\n")

    for group, group_df in df.groupby("Group"):
        f.write(f"\n\\subsection{{Group {group}}}\n")
        f.write("\\begin{table}[H]\n")
        f.write("\\centering\n")
        f.write(f"\\caption{{Kết quả test case nhóm {group}}}\n")
        f.write(f"\\label{{tab:group{group}}}\n")
        f.write(group_df.to_latex(index=False, escape=False))
        f.write("\\end{table}\n")

