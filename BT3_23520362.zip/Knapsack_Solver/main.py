from ortools.algorithms.python import knapsack_solver
import os 
import time 
import pandas as pd

def read_kp_file(filepath):
    with open(filepath, 'r') as f:
        lines = [line.strip() for line in f if line.strip()]
        num_items = int(lines[0])
        capacity = int(lines[1])
        values = []
        weights = []
        for line in lines[2:]:
            value, weight = map(int, line.split())
            values.append(value)
            weights.append(weight)
    return num_items, values, [weights], [capacity]

def solve_knapsack(values, weights, capacities, time_limit_ms):
    solver = knapsack_solver.KnapsackSolver(
        knapsack_solver.SolverType.KNAPSACK_MULTIDIMENSION_BRANCH_AND_BOUND_SOLVER,
        "KnapsackExperiment"
    )
    solver.init(values, weights, capacities)
    solver.set_time_limit(time_limit_ms)
    start = time.time()
    computed_value = solver.solve()
    elapsed = time.time() - start
    packed_items, total_weight = [], 0
    for i in range(len(values)):
        if solver.best_solution_contains(i):
            packed_items.append(i)
            total_weight += weights[0][i]
    return computed_value, total_weight, packed_items, solver.is_solution_optimal(), elapsed


def main():
    results = []
    time_limit = 180  # 3 minutes   
    for group in range(0, 13):  # groups 00 to 12
        group_dir = f"./Testcase/{group:02d}"
        for test_num in range(1, 6):  # test01.kp to test05.kp
            test_file = os.path.join(group_dir, f"test{test_num:02d}.kp")
            if os.path.exists(test_file):
                n, v, w, c = read_kp_file(test_file)
                val, tw, items, opt, time_used = solve_knapsack(v, w, c, time_limit)
                print(f"Group {group:02d} - Test {test_num:02d}")
                # print(f"  Total value : {total_value}")
                # print(f"  Total weight: {total_weight}")
                # print(f"  Packed items: {packed_items}")
                # print("-" * 40)
                results.append({
                "Group": f"{group:02d}",
                "Test": f"test{test_num:02d}",
                "Items": n,
                "Value": val,
                "Weight": tw,
                "IsOptimal": opt,
                "TimeUsed(s)": round(time_used, 2)
            })
            else:
                print(f"❌ Missing file: {test_file}")
        df = pd.DataFrame(results)
        df.to_csv("knapsack_results.csv", index=False)
        print("✅ Saved results to knapsack_results.csv")
if __name__ == "__main__":
    main()