#!/bin/bash

AGENTS=("Minimax" "AlphaBeta" "ExpectimaxAgent")
MAPS=("mediumClassic" "smallClassic" "capsuleClassic" "contestClassic" "openClassic")
EVALS=("scoreEvaluationFunction")
MSSV=23520362

for EVAL in "${EVALS[@]}"
do
  echo "Evaluation Function: $EVAL" >> results_$EVAL.txt
  for AGENT in "${AGENTS[@]}"
  do
    echo "Agent: $AGENT" >> results_$EVAL.txt
    for MAP in "${MAPS[@]}"
    do
      echo "Map: $MAP" >> results_$EVAL.txt
      echo "--- Summary Results ---" >> results_$EVAL.txt
      for ((i = 0; i < 5; i++))
      do
        SEED=$((MSSV + i))
        echo "Running with seed: $SEED"
        START=$(date +%s.%N)

        OUTPUT=$(python3 pacman.py -l $MAP -p $AGENT -a depth=3,evalFn=$EVAL -s $SEED --frameTime 0 2>&1)

        END=$(date +%s.%N)
        DURATION=$(echo "$END - $START" | bc)

        # Trích xuất điểm số
        SCORE=$(echo "$OUTPUT" | grep -Eo "Score: *-?[0-9]+" | tail -1 | awk '{print $2}')
        # Trích xuất kết quả
        if echo "$OUTPUT" | grep -q "Win"; then
            RESULT="Win"
        elif echo "$OUTPUT" | grep -qi "lose"; then
            RESULT="Loss"
        else
            RESULT="Unknown"
        fi

        printf "Seed %d | Score: %s | Result: %s | Time: %.2fs\n" "$SEED" "$SCORE" "$RESULT" "$DURATION" >> results_$EVAL.txt
      done
      echo "----------------------------------------" >> results_$EVAL.txt
    done
  done
done
